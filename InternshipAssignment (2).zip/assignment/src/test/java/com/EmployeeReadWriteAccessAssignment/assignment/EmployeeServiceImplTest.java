package com.EmployeeReadWriteAccessAssignment.assignment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.EmployeeReadWriteAccessAssignment.Repo.EmployeeRepository;
import com.EmployeeReadWriteAccessAssignment.Service.EmployeeServiceImpl;

public class EmployeeServiceImplTest {
	@Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1L, "John", "Doe", "john@example.com", "Developer"));
        employees.add(new Employee(2L, "Jane", "Doe", "jane@example.com", "Manager"));

        when(employeeRepository.findAll()).thenReturn(employees);

        List<Employee> result = employeeService.getAllEmployees();

        assertEquals(2, result.size());
    }

    @Test
    public void testGetEmployeeById() {
        Employee employee = new Employee(1L, "John", "Doe", "john@example.com", "Developer");

        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));

        Employee result = employeeService.getEmployeeById(1L);

        assertEquals(employee, result);
    }


}
